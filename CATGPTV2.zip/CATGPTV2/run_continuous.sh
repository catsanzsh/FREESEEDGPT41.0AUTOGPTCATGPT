#!/bin/bash

# Set the argument
argument="--continuous"

# Call the script or executable with the argument using Rosetta 2 if needed
arch -x86_64 ./run.sh "$argument"